package com.CourtAssist.service.scheduler;

import com.CourtAssist.service.courtdata.CourtDataImportService;
import com.CourtAssist.service.notification.NotificationProcessingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
public class CourtDataScheduler {

    private static final Logger logger = LoggerFactory.getLogger(CourtDataScheduler.class);

    private final CourtDataImportService courtDataImportService;
    private final NotificationProcessingService notificationProcessingService;

    public CourtDataScheduler(CourtDataImportService courtDataImportService,
                              NotificationProcessingService notificationProcessingService) {
        this.courtDataImportService = courtDataImportService;
        this.notificationProcessingService = notificationProcessingService;
    }

    /**
     * Execute immediately after application startup (for testing/development)
     */
    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady() {
        logger.info("Application started - executing immediate data import and notification processing");
        executeScheduledTask();
    }

    /**
     * Scheduled execution - runs multiple times per day
     * Schedule: 6:00 AM, 12:00 PM, 4:00 PM, 8:00 PM
     */
    @Scheduled(cron = "${court-data.scheduler.cron:0 0 6,12,16,20 * * ?}")
    public void scheduledExecution() {
        logger.info("Starting scheduled court data import and notification processing");
        executeScheduledTask();
    }

    /**
     * Core method that orchestrates data import and notification processing
     */
    @Transactional
    public void executeScheduledTask() {
        try {
            LocalDate targetDate = LocalDate.now().minusDays(7); // Process tomorrow's data

            logger.info("Starting court data scheduler execution for date: {}", targetDate);
            long startTime = System.currentTimeMillis();

//            // Step 1: Import court data
//            logger.info("Step 1: Importing court data...");
//            String importResult = courtDataImportService.importCourtDataForDate(targetDate);
//            logger.info("Court data import completed: {}", importResult);
//
            // Step 2: Process notifications
            logger.info("Step 2: Processing notifications...");
            notificationProcessingService.processUpcomingHearingNotificationsForDate(targetDate);
            logger.info("Notification processing completed");

            long endTime = System.currentTimeMillis();
            logger.info("Scheduler execution completed in {} ms", (endTime - startTime));

        } catch (Exception e) {
            logger.error("Error in scheduled task execution: {}", e.getMessage(), e);
            // You can add retry logic or alerting here
        }
    }

    /**
     * Manual trigger method for testing
     */
    public String triggerManualExecution() {
        logger.info("Manual execution triggered");
        try {
            executeScheduledTask();
            return "Manual execution completed successfully";
        } catch (Exception e) {
            return "Manual execution failed: " + e.getMessage();
        }
    }

    /**
     * Execute for specific date (useful for testing)
     */
    public String executeForSpecificDate(LocalDate date) {
        logger.info("Executing for specific date: {}", date);
        try {
            // Import data
            String importResult = courtDataImportService.importCourtDataForDate(date);

            // Process notifications
            notificationProcessingService.processUpcomingHearingNotificationsForDate(date);

            return String.format("Execution for date %s completed. Import: %s", date, importResult);
        } catch (Exception e) {
            return "Execution failed for date " + date + ": " + e.getMessage();
        }
    }
}