package com.CourtAssist.service.user;

import com.CourtAssist.model.UserSubscription;
import com.CourtAssist.repository.UserSubscriptionRepository;
import com.CourtAssist.repository.UsersRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserDeletionService {

    private final UserSubscriptionRepository subscriptionRepository;
    private final UsersRepository usersRepository;

    public UserDeletionService(UserSubscriptionRepository subscriptionRepository, UsersRepository usersRepository) {
        this.subscriptionRepository = subscriptionRepository;
        this.usersRepository = usersRepository;
    }

    @Transactional
    public void deleteUserWithSubscriptions(Long userId) {
        // Delete all subscriptions first
        List<UserSubscription> userSubscriptions = subscriptionRepository.findByUserId(userId);
        subscriptionRepository.deleteAll(userSubscriptions);

        // Then delete the user
        usersRepository.deleteById(userId);
    }
}