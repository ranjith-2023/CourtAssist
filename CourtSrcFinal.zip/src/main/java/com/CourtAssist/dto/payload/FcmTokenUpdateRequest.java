package com.CourtAssist.dto.payload;

import lombok.Data;

@Data
public class FcmTokenUpdateRequest {
    private String fcmToken;
}
