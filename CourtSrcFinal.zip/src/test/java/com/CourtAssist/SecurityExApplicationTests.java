package com.CourtAssist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityExApplicationTests {

	@Test
	void contextLoads() {
	}

}
