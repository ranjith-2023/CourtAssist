package com.CourtAssist.repository;

import com.CourtAssist.model.CourtCase;
import com.CourtAssist.model.UserSubscription;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface UserSubscriptionRepository extends JpaRepository<UserSubscription, Long> {
    @Query("SELECT us FROM UserSubscription us WHERE " +
            "us.courtLevel = :courtLevel AND " +
            "(:state IS NULL OR us.state = :state) AND " +
            "(:district IS NULL OR us.district = :district) AND " +
            "(:courtComplex IS NULL OR us.courtComplex = :courtComplex) AND " +
            "us.caseType = :caseType AND " +
            "us.caseNo = :caseNo AND " +
            "us.caseYear = :caseYear")
    List<UserSubscription> findSubscriptions(
            @Param("courtLevel") CourtCase.CourtLevel courtLevel,
            @Param("state") String state,
            @Param("district") String district,
            @Param("courtComplex") String courtComplex,
            @Param("caseType") String caseType,
            @Param("caseNo") String caseNo,
            @Param("caseYear") Integer caseYear
    );

    @Query("SELECT us FROM UserSubscription us WHERE us.user.userId = :userId")
    List<UserSubscription> findByUserId(@Param("userId") Long userId);

    List<UserSubscription> findByAdvocateName(String advocateName);

    @Query("SELECT us FROM UserSubscription us WHERE us.user.userId IS NULL OR NOT EXISTS " +
            "(SELECT u FROM Users u WHERE u.userId = us.user.userId)")
    List<UserSubscription> findOrphanedSubscriptions();

    int deleteByUser_UsernameLike(String usernamePattern);
    @Query("SELECT us FROM UserSubscription us WHERE us.user.userId = :userId AND us.subscriptionType = :subscriptionType")
    List<UserSubscription> findByUserIdAndSubscriptionType(
            @Param("userId") Long userId,
            @Param("subscriptionType") UserSubscription.SubscriptionType subscriptionType
    );
    
}