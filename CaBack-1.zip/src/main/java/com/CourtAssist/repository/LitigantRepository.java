package com.CourtAssist.repository;

import com.CourtAssist.model.Litigant;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LitigantRepository extends JpaRepository<Litigant, Long> {
    @Query("SELECT l FROM Litigant l WHERE l.case_.caseId = :caseId")
    Optional<Litigant> findByCaseId(@Param("caseId") String caseId);

    // Find by case ID and petitioner name
    @Query("SELECT l FROM Litigant l WHERE l.case_.caseId = :caseId AND l.petitioner = :petitioner")
    Optional<Litigant> findByCaseIdAndPetitioner(@Param("caseId") String caseId, @Param("petitioner") String petitioner);

    // Find by case ID and respondent name
    @Query("SELECT l FROM Litigant l WHERE l.case_.caseId = :caseId AND l.respondent = :respondent")
    Optional<Litigant> findByCaseIdAndRespondent(@Param("caseId") String caseId, @Param("respondent") String respondent);
}