package com.CourtAssist.repository;

import com.CourtAssist.dto.NotificationDTO;
import com.CourtAssist.model.Notification;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    @Query("SELECT n FROM Notification n WHERE n.user.userId = :userId")
    List<Notification> findByUserId(@Param("userId") Long userId);

    @Query("SELECT new com.CourtAssist.dto.NotificationDTO(" +
            "n.id, n.caseNo, n.caseYear, n.hearingDatetime, " +
            "n.courtLevel, n.state, n.district, n.courtComplex, " +
            "n.courtNo, n.stage, n.petitioner, n.respondent, " +
            "n.petitionerAdv, n.respondentAdv, n.createdAt, n.isRead) " +
            "FROM Notification n WHERE n.user.userId = :userId")
    List<NotificationDTO> findDTOByUserId(@Param("userId") Long userId);

    @Modifying
    @Transactional
    @Query("UPDATE Notification n SET n.isRead = true WHERE n.id = :id")
    void markAsRead(@Param("id") Long id);

    @Modifying
    @Transactional
    @Query("UPDATE Notification n SET n.isRead = true WHERE n.user.userId = :userId")
    void markAllAsReadByUserId(@Param("userId") Long userId);

    @Query("SELECT COUNT(n) FROM Notification n WHERE n.user.userId = :userId AND n.isRead = false")
    Long countUnreadByUserId(@Param("userId") Long userId);

}