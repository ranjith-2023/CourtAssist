package com.CourtAssist.repository;

import com.CourtAssist.model.Advocate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AdvocateRepository extends JpaRepository<Advocate, Long> {
    @Query("SELECT a FROM Advocate a WHERE a.case_.caseId = :caseId")
    Optional<Advocate> findByCaseId(@Param("caseId") String caseId);

    @Query("SELECT a FROM Advocate a WHERE a.case_.caseId = :caseId")
    List<Advocate> findAllByCaseId(@Param("caseId") String caseId);

    @Query("SELECT a FROM Advocate a WHERE a.case_.caseId = :caseId AND a.petitionerAdv = :petitionerAdv")
    Optional<Advocate> findByCaseIdAndPetitionerAdv(@Param("caseId") String caseId, @Param("petitionerAdv") String petitionerAdv);

    @Query("SELECT a FROM Advocate a WHERE a.case_.caseId = :caseId AND a.respondentAdv = :respondentAdv")
    Optional<Advocate> findByCaseIdAndRespondentAdv(@Param("caseId") String caseId, @Param("respondentAdv") String respondentAdv);
}