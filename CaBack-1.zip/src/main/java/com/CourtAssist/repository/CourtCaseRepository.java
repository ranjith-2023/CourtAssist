package com.CourtAssist.repository;
import com.CourtAssist.model.CourtCase;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CourtCaseRepository extends JpaRepository<CourtCase, String> {
    List<CourtCase> findByStateAndDistrictAndCourtComplexAndCaseTypeAndCaseNoAndCaseYear(
            String state, String district, String courtComplex, String caseType, String caseNo, Integer caseYear);

    List<CourtCase> findByParentCase(CourtCase parentCase);

    List<CourtCase> findByCaseType(String type);
}