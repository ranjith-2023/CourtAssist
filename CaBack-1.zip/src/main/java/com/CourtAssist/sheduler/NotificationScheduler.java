package com.CourtAssist.sheduler;

import com.CourtAssist.service.notification.NotificationProcessingService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class NotificationScheduler {
    private final NotificationProcessingService notificationService;

    public NotificationScheduler(NotificationProcessingService notificationService) {
        this.notificationService = notificationService;
    }

    @Scheduled(cron = "0 0 8 * * ?") // Run daily at 8 AM
    public void processDailyNotifications() {
        notificationService.processUpcomingHearingNotifications();
    }
}