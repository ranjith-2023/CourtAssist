package com.CourtAssist.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "user_subscriptions")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserSubscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Users user;

    @Enumerated(EnumType.STRING)
    private SubscriptionType subscriptionType;

    @Enumerated(EnumType.STRING)
    @Column(name = "court_level")
    private CourtCase.CourtLevel courtLevel;

    private String state;
    private String district;
    private String courtComplex;
    private String courtName;
    private String caseType;
    private String caseNo;
    private Integer caseYear;
    private String advocateName;
    private String litigantName;

    public enum SubscriptionType {
        CASE_BASED,
        ADVOCATE_BASED
    }
}