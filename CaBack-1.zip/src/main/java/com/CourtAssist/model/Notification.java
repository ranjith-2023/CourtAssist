package com.CourtAssist.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "notifications")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Users user;

    @ManyToOne
    @JoinColumn(name = "case_id", nullable = false)
    private CourtCase case_;

    @Column(nullable = false, name = "hearing_id")
    private String hearingId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, name = "court_level")
    private CourtCase.CourtLevel courtLevel;

    @Column(nullable = false)
    private String state;

    @Column(nullable = false)
    private String district;

    @Column(name = "court_complex")
    private String courtComplex;

    @Column(nullable = false,name = "case_type")
    private String caseType;

    @Column(nullable = false, name = "case_no")
    private String caseNo;

    @Column(nullable = false, name = "case_year")
    private Integer caseYear;

    @Column(nullable = false, name = "court_no")
    private String courtNo;

    @Column
    private String stage;

    @Column(nullable = false, name = "hearing_datetime")
    private LocalDateTime hearingDatetime;

    @Column(nullable = false)
    private String petitioner;

    @Column(nullable = false)
    private String respondent;

    @Column(nullable = false, name = "petitioner_adv")
    private String petitionerAdv;

    @Column(nullable = false, name = "respondent_adv")
    private String respondentAdv;

    @CreationTimestamp
    private LocalDateTime createdAt;

    @Column(insertable = false, updatable = false)
    private LocalDateTime expiryDate;

    @Column(name = "is_read")
    private Boolean isRead = false;
}