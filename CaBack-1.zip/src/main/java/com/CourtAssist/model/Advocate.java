package com.CourtAssist.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "advocates")
public class Advocate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private CourtCase case_;

    @Column(nullable = false, name = "petitioner_adv")
    private String petitionerAdv;

    @Column(nullable = false, name = "respondent_adv")
    private String respondentAdv;

    @CreationTimestamp
    private LocalDateTime createdAt;
}