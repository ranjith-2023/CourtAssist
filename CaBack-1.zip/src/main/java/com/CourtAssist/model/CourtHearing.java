package com.CourtAssist.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "court_hearings")
public class CourtHearing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, name = "hearing_id")
    private String hearingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private CourtCase courtCase;

    @Column(nullable = false, name = "court_no")
    private String courtNo;

    @Column(nullable = false)
    private String stage;

    @Column(nullable = false, name = "hearing_datetime")
    private LocalDateTime hearingDatetime;

    @Column(name = "court_remarks")
    private String courtRemarks;

    @CreationTimestamp
    private LocalDateTime createdAt;
}