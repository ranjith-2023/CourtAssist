package com.CourtAssist.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "court_cases")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CourtCase {
    @Id
    private String caseId;

    @Enumerated(EnumType.STRING)
    @Column(name = "court_level")
    private CourtLevel courtLevel;

    private String state;
    private String district;
    private String courtComplex;
    private String courtName;
    private String caseType;
    private String caseNo;
    private Integer caseYear;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_case_id")
    private CourtCase parentCase;

    @OneToMany(mappedBy = "courtCase", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CourtHearing> hearings = new ArrayList<>();

    @OneToMany(mappedBy = "case_", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Litigant> litigants = new ArrayList<>();

    @OneToMany(mappedBy = "case_", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Advocate> advocates = new ArrayList<>();

    public enum CourtLevel {
        SUPREME_COURT,
        HIGH_COURT,
        DISTRICT_COURT,
    }

    // Helper methods to maintain bidirectional relationships
    public void addHearing(CourtHearing hearing) {
        hearings.add(hearing);
        hearing.setCourtCase(this);
    }

    public void addLitigant(Litigant litigant) {
        litigants.add(litigant);
        litigant.setCase_(this);
    }

    public void addAdvocate(Advocate advocate) {
        advocates.add(advocate);
        advocate.setCase_(this);
    }

    @PrePersist
    @PreUpdate
    private void validateRequiredFields() {
        if (caseType == null) throw new IllegalArgumentException("caseType cannot be null");
        if (caseNo == null) throw new IllegalArgumentException("caseNo cannot be null");
        if (caseYear == null) throw new IllegalArgumentException("caseYear cannot be null");
        if (courtLevel == null) throw new IllegalArgumentException("courtLevel cannot be null");
    }
}