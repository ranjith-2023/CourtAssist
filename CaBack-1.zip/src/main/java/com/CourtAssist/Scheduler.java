package com.CourtAssist;//package com.CourtAssist3;
//
//import com.CourtAssist3.service.NotificationService;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Component;
//
//import java.time.LocalDateTime;
//
//@Component
//public class Scheduler {
//    private final NotificationService notificationService;
//
//    public Scheduler(NotificationService notificationService) {
//        this.notificationService = notificationService;
//    }
//
//    @Scheduled(cron = "0 0 8 * * ?") // Run daily at 8 AM
//    public void processDailyNotifications() {
//        System.out.println("Starting daily notification processing at: " + LocalDateTime.now());
//        notificationService.processUpcomingHearingNotifications();
//    }
//
//    @Scheduled(cron = "0 0/30 8-17 * * MON-FRI") // Run every 30 minutes from 8 AM to 5 PM on weekdays
//    public void processRealTimeNotifications() {
//        System.out.println("Starting real-time notification processing at: " + LocalDateTime.now());
//        notificationService.processUpcomingHearingNotifications();
//    }
//}