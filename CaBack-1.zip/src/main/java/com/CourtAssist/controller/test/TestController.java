package com.CourtAssist.controller.test;

import com.CourtAssist.service.courtdata.CourtDataImportService;
import com.CourtAssist.service.notification.NotificationProcessingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/api/test")
public class TestController {

    @Autowired
    private CourtDataImportService courtDataImportService;

    @Autowired
    private NotificationProcessingService notificationProcessingService;

    // Test court data import
    @PostMapping("/import")
    public Map<String, Object> testImport() {
        Map<String, Object> result = new HashMap<>();
        try {
            String importResult = courtDataImportService.importCourtDataForDate(LocalDate.now().plusDays(1));
            result.put("success", true);
            result.put("data", importResult);
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }

    // Test notification processing
    @PostMapping("/notifications")
    public Map<String, Object> testNotifications() {
        Map<String, Object> result = new HashMap<>();
        try {
            notificationProcessingService.processUpcomingHearingNotificationsForDate(LocalDate.now().plusDays(1));
            result.put("success", true);
            result.put("data", "Notifications processed successfully");
        } catch (Exception e) {
            result.put("success", false);
            result.put("error", e.getMessage());
        }
        return result;
    }
}