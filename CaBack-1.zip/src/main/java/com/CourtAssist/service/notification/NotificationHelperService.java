package com.CourtAssist.service.notification;

import com.CourtAssist.dto.HearingNotificationDTO;
import com.CourtAssist.service.contact.EmailService;
import com.CourtAssist.service.contact.SmsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class NotificationHelperService {
    private static final Logger logger = LoggerFactory.getLogger(NotificationHelperService.class);

    private final EmailService emailService;
    private final SmsService smsService;

    public NotificationHelperService(EmailService emailService, SmsService smsService) {
        this.emailService = emailService;
        this.smsService = smsService;
    }

    public void sendHearingNotification(String email, String mobile, HearingNotificationDTO dto) {
        int sentCount = 0;

        if (email != null && !email.trim().isEmpty()) {
            try {
                String subject = "Hearing Alert for Case: " + dto.getCaseNumber();
                String body = formatEmailBody(dto);
                emailService.sendMail(email, subject, body);
                sentCount++;
                logger.info("Email notification sent to {} for case {}", email, dto.getCaseNumber());
            } catch (Exception e) {
                logger.error("Failed to send email to {}: {}", email, e.getMessage());
            }
        }

        if (mobile != null && !mobile.trim().isEmpty()) {
            try {
                String message = formatSMSMessage(dto);
                smsService.sendSMS(mobile, message);
                sentCount++;
                logger.info("SMS notification sent to {} for case {}", mobile, dto.getCaseNumber());
            } catch (Exception e) {
                logger.error("Failed to send SMS to {}: {}", mobile, e.getMessage());
            }
        }

        if (sentCount == 0) {
            logger.warn("No notifications sent for case {} - no valid email or mobile", dto.getCaseNumber());
        }
    }

    private String formatEmailBody(HearingNotificationDTO dto) {
        StringBuilder body = new StringBuilder();
        body.append("HEARING ALERT NOTIFICATION\n");
        body.append("==========================\n\n");

        body.append(String.format("Case Number: %s\n", dto.getCaseNumber()));
        body.append(String.format("Hearing Date: %s\n", dto.getHearingDateTime().toLocalDate()));
        body.append(String.format("Hearing Time: %s\n", dto.getHearingDateTime().toLocalTime()));
        body.append(String.format("Court: %s\n", dto.getCourtName()));
        body.append(String.format("Stage: %s\n", dto.getStage()));

        body.append("\nPARTIES INVOLVED:\n");
        body.append(String.format("Petitioner: %s\n", safeNull(dto.getPetitionerName())));
        body.append(String.format("Respondent: %s\n", safeNull(dto.getRespondentName())));

        body.append("\nLEGAL REPRESENTATION:\n");
        body.append(String.format("Petitioner Advocate: %s\n", safeNull(dto.getPetitionerAdvocate())));
        body.append(String.format("Respondent Advocate: %s\n", safeNull(dto.getRespondentAdvocate())));

        body.append("\nIMPORTANT NOTES:\n");
        body.append("- Please arrive at the court complex at least 30 minutes before the hearing\n");
        body.append("- Carry all relevant documents and identification\n");
        body.append("- Contact your advocate for any last-minute instructions\n");

        body.append("\n---\n");
        body.append("This is an automated notification from CourtAssist System\n");

        return body.toString();
    }

    private String formatSMSMessage(HearingNotificationDTO dto) {
        // SMS has character limits, so keep it concise
        return String.format(
                "Court Hearing: %s on %s at %s. Court: %s. Stage: %s. P: %s. R: %s",
                dto.getCaseNumber(),
                dto.getHearingDateTime().toLocalDate(),
                dto.getHearingDateTime().toLocalTime(),
                abbreviateText(dto.getCourtName(), 20),
                abbreviateText(dto.getStage(), 15),
                abbreviateName(dto.getPetitionerName()),
                abbreviateName(dto.getRespondentName())
        );
    }

    private String safeNull(String value) {
        return value != null && !value.trim().isEmpty() ? value : "Not specified";
    }

    private String abbreviateName(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) {
            return "N/A";
        }

        String cleanName = fullName.trim();
        String[] parts = cleanName.split("\\s+");

        if (parts.length == 1) {
            return parts[0];
        }

        // Return first name + last initial
        return parts[0] + " " + parts[parts.length - 1].charAt(0) + ".";
    }

    private String abbreviateText(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 3) + "...";
    }
}