package com.CourtAssist.service.notification;

import com.CourtAssist.dto.HearingNotificationDTO;
import com.CourtAssist.model.*;
import com.CourtAssist.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.apache.commons.text.similarity.LevenshteinDistance;
import org.springframework.util.StringUtils;

import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class NotificationProcessingService {

    private static final Logger logger = LoggerFactory.getLogger(NotificationProcessingService.class);

    private final UsersRepository usersRepository;
    private final CourtHearingRepository hearingRepository;
    private final UserSubscriptionRepository subscriptionRepository;
    private final CourtCaseRepository caseRepository;
    private final LitigantRepository litigantRepository;
    private final AdvocateRepository advocateRepository;
    private final NotificationHelperService notificationHelperService;
    private final NotificationRepository notificationRepository;

    public NotificationProcessingService(UsersRepository usersRepository, CourtHearingRepository hearingRepository,
                                         UserSubscriptionRepository subscriptionRepository,
                                         CourtCaseRepository caseRepository,
                                         LitigantRepository litigantRepository,
                                         AdvocateRepository advocateRepository,
                                         NotificationHelperService notificationHelperService,
                                         NotificationRepository notificationRepository) {
        this.usersRepository = usersRepository;
        this.hearingRepository = hearingRepository;
        this.subscriptionRepository = subscriptionRepository;
        this.caseRepository = caseRepository;
        this.litigantRepository = litigantRepository;
        this.advocateRepository = advocateRepository;
        this.notificationHelperService = notificationHelperService;
        this.notificationRepository = notificationRepository;
    }

    private static final double SIMILARITY_THRESHOLD = 0.8;
    private static final Set<String> COMMON_TITLES = Set.of(
            "mr", "mrs", "ms", "dr", "adv", "advocate", "prof", "justice",
            "honorable", "hon", "shri", "smt", "kum", "m/s", "m/s."
    );
    private static final Set<String> LEGAL_SUFFIXES = Set.of(
            "pc", "llp", "llc", "co", "ltd", "inc", "pllc"
    );
    private static final Pattern MULTIPLE_NAMES_PATTERN = Pattern.compile(
            "[,&]|\\band\\b", Pattern.CASE_INSENSITIVE
    );
    private static final Pattern NON_NAME_CHARACTERS = Pattern.compile(
            "[^a-zA-Z\\s.]", Pattern.CASE_INSENSITIVE
    );

    @Transactional
    public void processUpcomingHearingNotifications() {
        processUpcomingHearingNotificationsForDate(LocalDate.now().plusDays(1));
    }

    @Transactional
    public void processUpcomingHearingNotificationsForDate(LocalDate date) {
        LocalDateTime startTime = date.atStartOfDay();
        LocalDateTime endTime = date.atTime(23, 59, 59);

        logger.info("Processing hearings between {} and {} for date {}", startTime, endTime, date);

        List<CourtHearing> upcomingHearings = hearingRepository.findByHearingDatetimeBetween(startTime, endTime);
        logger.info("Found {} upcoming hearings for date {}", upcomingHearings.size(), date);

        int notificationCount = 0;
        int matchedUsersCount = 0;

        for (CourtHearing hearing : upcomingHearings) {
            int[] results = processHearingNotifications(hearing);
            notificationCount += results[0];
            matchedUsersCount += results[1];
        }

        logger.info("Processed {} notifications for {} unique users for date {}",
                notificationCount, matchedUsersCount, date);
    }

    private int[] processHearingNotifications(CourtHearing hearing) {
        int notificationCount = 0;
        int matchedUsersCount = 0;
        Set<Long> processedUsers = new HashSet<>(); // Track users to avoid duplicates

        try {
            CourtCase mainCase = hearing.getCourtCase();
            List<CourtCase> allCases = new ArrayList<>();
            allCases.add(mainCase);
            allCases.addAll(caseRepository.findByParentCase(mainCase));

            for (CourtCase courtCase : allCases) {
                List<UserSubscription> matchingSubscriptions = findMatchingSubscriptions(courtCase);
                logger.debug("Found {} matching subscriptions for case {}", matchingSubscriptions.size(), courtCase.getCaseId());

                for (UserSubscription subscription : matchingSubscriptions) {
                    try {
                        if (subscription.getUser() == null) {
                            logger.warn("Skipping subscription {} with null user reference", subscription.getId());
                            continue;
                        }

                        Optional<Users> userOptional = usersRepository.findById(subscription.getUser().getUserId());
                        if (userOptional.isEmpty()) {
                            logger.warn("Skipping subscription {} with non-existent user ID: {}",
                                    subscription.getId(), subscription.getUser().getUserId());
                            continue;
                        }

                        Users user = userOptional.get();

                        // Avoid sending multiple notifications to same user for same hearing
                        if (processedUsers.contains(user.getUserId())) {
                            logger.debug("User {} already processed for this hearing, skipping duplicate", user.getUserId());
                            continue;
                        }

                        Optional<HearingNotificationDTO> notificationDto = createNotificationDto(hearing, courtCase);
                        if (notificationDto.isPresent()) {
                            // Use the improved NotificationHelperService
                            notificationHelperService.sendHearingNotification(
                                    user.getEmail(),
                                    user.getMobileNo(),
                                    notificationDto.get()
                            );

                            saveNotification(user, hearing, courtCase, notificationDto.get());
                            notificationCount++;
                            matchedUsersCount++;
                            processedUsers.add(user.getUserId());

                            logger.debug("Sent notification to user {} for case {}",
                                    user.getUserId(), courtCase.getCaseId());
                        }
                    } catch (Exception e) {
                        logger.error("Failed to process subscription {}: {}", subscription.getId(), e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            logger.error("Failed to process notifications for hearing {}: {}", hearing.getHearingId(), e.getMessage());
        }

        return new int[]{notificationCount, matchedUsersCount};
    }

    private List<UserSubscription> findMatchingSubscriptions(CourtCase courtCase) {
        List<UserSubscription> allSubscriptions = subscriptionRepository.findAll();
        logger.debug("Checking {} subscriptions against case {}", allSubscriptions.size(), courtCase.getCaseId());

        return allSubscriptions.stream()
                .filter(subscription -> matchesSubscription(subscription, courtCase))
                .collect(Collectors.toList());
    }

    private boolean matchesSubscription(UserSubscription subscription, CourtCase courtCase) {
        try {
            boolean matches = (subscription.getState() == null || fuzzyStringMatch(subscription.getState(), courtCase.getState())) &&
                    (subscription.getDistrict() == null || fuzzyStringMatch(subscription.getDistrict(), courtCase.getDistrict())) &&
                    (subscription.getCourtComplex() == null || fuzzyStringMatch(subscription.getCourtComplex(), courtCase.getCourtComplex())) &&
                    (subscription.getCaseType() == null || fuzzyStringMatch(subscription.getCaseType(), courtCase.getCaseType())) &&
                    (subscription.getCaseNo() == null || fuzzyStringMatch(subscription.getCaseNo(), courtCase.getCaseNo())) &&
                    (subscription.getCaseYear() == null || Objects.equals(subscription.getCaseYear(), courtCase.getCaseYear())) &&
                    (subscription.getAdvocateName() == null || matchesAdvocate(subscription.getAdvocateName(), courtCase.getCaseId())) &&
                    (subscription.getLitigantName() == null || matchesLitigantEnhanced(subscription.getLitigantName(), courtCase.getCaseId()));

            if (matches) {
                logger.debug("Subscription {} matched case {}", subscription.getId(), courtCase.getCaseId());
            }

            return matches;
        } catch (Exception e) {
            logger.error("Error matching subscription for case {}: {}", courtCase.getCaseId(), e.getMessage());
            return false;
        }
    }

    /**
     * ENHANCED: Now handles partial name matching (e.g., "Dhanasekaran" matches "M/s.b.manoharan B.dhanasekaran")
     */
    private boolean matchesLitigantEnhanced(String subscriptionLitigant, String caseId) {
        if (!StringUtils.hasText(subscriptionLitigant)) return true;

        Optional<Litigant> litigantOpt = litigantRepository.findByCaseId(caseId);
        if (!litigantOpt.isPresent()) {
            return false;
        }

        Litigant litigant = litigantOpt.get();
        String petitioner = litigant.getPetitioner();
        String respondent = litigant.getRespondent();

        // Normalize subscription name
        String normalizedSubscription = normalizeName(subscriptionLitigant);

        // Extract individual name parts from subscription
        List<String> subscriptionNameParts = extractIndividualNames(normalizedSubscription);

        // Check petitioner with enhanced matching
        if (StringUtils.hasText(petitioner)) {
            String normalizedPetitioner = normalizeName(petitioner);
            List<String> petitionerNameParts = extractIndividualNames(normalizedPetitioner);

            if (containsAnyNamePart(subscriptionNameParts, petitionerNameParts)) {
                logger.debug("Litigant match found in petitioner: '{}' in '{}'", subscriptionLitigant, petitioner);
                return true;
            }
        }

        // Check respondent with enhanced matching
        if (StringUtils.hasText(respondent)) {
            String normalizedRespondent = normalizeName(respondent);
            List<String> respondentNameParts = extractIndividualNames(normalizedRespondent);

            if (containsAnyNamePart(subscriptionNameParts, respondentNameParts)) {
                logger.debug("Litigant match found in respondent: '{}' in '{}'", subscriptionLitigant, respondent);
                return true;
            }
        }

        return false;
    }

    private boolean matchesAdvocate(String subscriptionAdvocate, String caseId) {
        if (!StringUtils.hasText(subscriptionAdvocate)) return true;

        Optional<Advocate> advocateOpt = advocateRepository.findByCaseId(caseId);
        if (!advocateOpt.isPresent()) {
            return false;
        }

        Advocate advocate = advocateOpt.get();
        String petitionerAdv = advocate.getPetitionerAdv();
        String respondentAdv = advocate.getRespondentAdv();

        // Normalize subscription name
        String normalizedSubscription = normalizeName(subscriptionAdvocate);
        List<String> subscriptionNameParts = extractIndividualNames(normalizedSubscription);

        // Check petitioner advocate with enhanced matching
        if (StringUtils.hasText(petitionerAdv)) {
            String normalizedPetitionerAdv = normalizeName(petitionerAdv);
            List<String> petitionerAdvParts = extractIndividualNames(normalizedPetitionerAdv);

            if (containsAnyNamePart(subscriptionNameParts, petitionerAdvParts)) {
                logger.debug("Advocate match found in petitioner advocate: '{}' in '{}'",
                        subscriptionAdvocate, petitionerAdv);
                return true;
            }
        }

        // Check respondent advocate with enhanced matching
        if (StringUtils.hasText(respondentAdv)) {
            String normalizedRespondentAdv = normalizeName(respondentAdv);
            List<String> respondentAdvParts = extractIndividualNames(normalizedRespondentAdv);

            if (containsAnyNamePart(subscriptionNameParts, respondentAdvParts)) {
                logger.debug("Advocate match found in respondent advocate: '{}' in '{}'",
                        subscriptionAdvocate, respondentAdv);
                return true;
            }
        }

        return false;
    }

    /**
     * NEW: Extract individual names from a string (handles multiple names)
     */
    private List<String> extractIndividualNames(String nameString) {
        if (!StringUtils.hasText(nameString)) {
            return Collections.emptyList();
        }

        List<String> names = new ArrayList<>();

        // Split by common separators
        String[] primarySplit = MULTIPLE_NAMES_PATTERN.split(nameString);

        for (String part : primarySplit) {
            // Further split by spaces to get individual name components
            String[] nameParts = part.trim().split("\\s+");

            for (String namePart : nameParts) {
                // Ignore single letters/initials and common words
                if (StringUtils.hasText(namePart) && namePart.length() > 1 && !isCommonWord(namePart)) {
                    names.add(namePart.trim().toLowerCase());
                }
            }
        }

        return names;
    }

    /**
     * NEW: Check if any subscription name part matches any case name part
     */
    private boolean containsAnyNamePart(List<String> subscriptionNames, List<String> caseNames) {
        for (String subName : subscriptionNames) {
            for (String caseName : caseNames) {
                // Use fuzzy matching for individual name parts
                if (fuzzyStringMatchEnhanced(subName, caseName)) {
                    logger.debug("Name part fuzzy match: '{}' vs '{}'", subName, caseName);
                    return true;
                }

                // Also check direct containment for better matching
                if (caseName.contains(subName) || subName.contains(caseName)) {
                    logger.debug("Name part containment: '{}' in '{}'", subName, caseName);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * ENHANCED fuzzy matching with partial matching support
     */
    private boolean fuzzyStringMatchEnhanced(String str1, String str2) {
        if (str1 == null || str2 == null) return false;
        if (str1.equalsIgnoreCase(str2)) return true;

        String s1 = str1.toLowerCase();
        String s2 = str2.toLowerCase();

        if (s1.equals(s2)) return true;

        // NEW: Check if one string contains the other (partial match)
        if (s1.contains(s2) || s2.contains(s1)) {
            double containmentSimilarity = calculateContainmentSimilarity(s1, s2);
            if (containmentSimilarity >= SIMILARITY_THRESHOLD) {
                return true;
            }
        }

        // Original Levenshtein distance calculation
        LevenshteinDistance levenshtein = new LevenshteinDistance();
        int distance = levenshtein.apply(s1, s2);
        double maxLength = Math.max(s1.length(), s2.length());

        if (maxLength == 0) return false; // Avoid division by zero

        double similarity = 1.0 - (distance / maxLength);

        return similarity >= SIMILARITY_THRESHOLD;
    }

    /**
     * NEW: Calculate similarity based on string containment
     */
    private double calculateContainmentSimilarity(String str1, String str2) {
        String longer = str1.length() >= str2.length() ? str1 : str2;
        String shorter = str1.length() < str2.length() ? str1 : str2;

        if (longer.contains(shorter)) {
            return (double) shorter.length() / longer.length();
        }

        return 0.0;
    }

    /**
     * Check if a word is too common to be considered a name part
     */
    private boolean isCommonWord(String word) {
        Set<String> commonWords = Set.of("and", "or", "the", "vs", "versus", "state", "union", "government");
        return commonWords.contains(word.toLowerCase());
    }

    private String normalizeName(String name) {
        if (!StringUtils.hasText(name)) return "";

        String normalized = name.toLowerCase().trim();

        // Remove common titles
        for (String title : COMMON_TITLES) {
            normalized = normalized.replaceAll("\\b" + title + "\\.?\\s*", "");
        }

        // Remove legal suffixes
        for (String suffix : LEGAL_SUFFIXES) {
            normalized = normalized.replaceAll("\\s*" + suffix + "\\.?\\s*", "");
        }

        // Remove non-name characters
        normalized = NON_NAME_CHARACTERS.matcher(normalized).replaceAll("");

        // Standardize whitespace
        normalized = normalized.replaceAll("\\s+", " ").trim();

        // Remove trailing dots
        normalized = normalized.replaceAll("\\.$", "");

        return normalized;
    }

    private List<String> splitMultipleNames(String names) {
        if (!StringUtils.hasText(names)) return Collections.emptyList();

        return Arrays.stream(MULTIPLE_NAMES_PATTERN.split(names))
                .map(String::trim)
                .filter(StringUtils::hasText)
                .collect(Collectors.toList());
    }

    // Keep original fuzzyStringMatch for backward compatibility
    private boolean fuzzyStringMatch(String str1, String str2) {
        return fuzzyStringMatchEnhanced(str1, str2);
    }

    private Optional<HearingNotificationDTO> createNotificationDto(CourtHearing hearing, CourtCase courtCase) {
        try {
            Optional<Litigant> litigantOpt = litigantRepository.findByCaseId(courtCase.getCaseId());
            Optional<Advocate> advocateOpt = advocateRepository.findByCaseId(courtCase.getCaseId());

            if (!litigantOpt.isPresent() || !advocateOpt.isPresent()) {
                logger.warn("Missing litigant or advocate data for case {}", courtCase.getCaseId());
                return Optional.empty();
            }

            Litigant litigant = litigantOpt.get();
            Advocate advocate = advocateOpt.get();

            String caseNumber = String.format("%s/%d", courtCase.getCaseNo(), courtCase.getCaseYear());
            String courtName = String.format("%s - %s", courtCase.getCourtComplex(), courtCase.getCourtLevel());

            boolean isExtraCase = courtCase.getParentCase() != null;
            String caseRelation = isExtraCase ? " (Related Case)" : "";

            HearingNotificationDTO dto = new HearingNotificationDTO(
                    caseNumber + caseRelation,
                    hearing.getHearingDatetime(),
                    courtName,
                    hearing.getStage(),
                    hearing.getHearingId(),
                    litigant.getPetitioner(),
                    litigant.getRespondent(),
                    advocate.getPetitionerAdv(),
                    advocate.getRespondentAdv()
            );

            return Optional.of(dto);
        } catch (Exception e) {
            logger.error("Failed to create notification DTO for case {}: {}", courtCase.getCaseId(), e.getMessage());
            return Optional.empty();
        }
    }

    private void saveNotification(Users user, CourtHearing hearing, CourtCase courtCase, HearingNotificationDTO dto) {
        try {
            Optional<Litigant> litigantOpt = litigantRepository.findByCaseId(courtCase.getCaseId());
            Optional<Advocate> advocateOpt = advocateRepository.findByCaseId(courtCase.getCaseId());

            if (!litigantOpt.isPresent() || !advocateOpt.isPresent()) {
                return;
            }

            Litigant litigant = litigantOpt.get();
            Advocate advocate = advocateOpt.get();

            Notification notification = new Notification();
            notification.setUser(user);
            notification.setCase_(courtCase);
            notification.setHearingId(hearing.getHearingId());
            notification.setCourtLevel(courtCase.getCourtLevel());
            notification.setState(courtCase.getState());
            notification.setDistrict(courtCase.getDistrict());
            notification.setCourtComplex(courtCase.getCourtComplex());
            notification.setCaseType(courtCase.getCaseType());
            notification.setCaseNo(courtCase.getCaseNo());
            notification.setCaseYear(courtCase.getCaseYear());
            notification.setCourtNo(hearing.getCourtNo());
            notification.setStage(hearing.getStage());
            notification.setHearingDatetime(hearing.getHearingDatetime());
            notification.setPetitioner(litigant.getPetitioner());
            notification.setRespondent(litigant.getRespondent());
            notification.setPetitionerAdv(advocate.getPetitionerAdv());
            notification.setRespondentAdv(advocate.getRespondentAdv());
            notification.setIsRead(false);
            notification.setCreatedAt(LocalDateTime.now());

            notificationRepository.save(notification);
            logger.debug("Saved notification for user {} and case {}", user.getUserId(), courtCase.getCaseId());
        } catch (Exception e) {
            logger.error("Failed to save notification for user {} and case {}: {}",
                    user.getUserId(), courtCase.getCaseId(), e.getMessage());
        }
    }

    /**
     * Additional method for testing specific subscriptions
     */
    public void testSubscriptionMatching(Long subscriptionId, String caseId) {
        Optional<UserSubscription> subscriptionOpt = subscriptionRepository.findById(subscriptionId);
        Optional<CourtCase> caseOpt = caseRepository.findById(caseId);

        if (subscriptionOpt.isPresent() && caseOpt.isPresent()) {
            boolean matches = matchesSubscription(subscriptionOpt.get(), caseOpt.get());
            logger.info("Test result: Subscription {} {} case {}",
                    subscriptionId, matches ? "MATCHES" : "DOES NOT MATCH", caseId);
        } else {
            logger.warn("Subscription or case not found for testing");
        }
    }
}