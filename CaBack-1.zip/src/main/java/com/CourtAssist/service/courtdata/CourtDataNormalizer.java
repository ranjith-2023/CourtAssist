package com.CourtAssist.service.courtdata;

import java.util.*;
import java.util.regex.*;
import java.util.stream.Collectors;
import java.text.Normalizer;

public class CourtDataNormalizer {

    // Common legal terms to exclude (case-insensitive)
    private static final Set<String> LEGAL_TERMS = new HashSet<>(Arrays.asList(
            "died", "steps due", "vide court order", "tapal returned", "insufficient address",
            "paper publication", "proof filed", "court notice", "dispense with", "fresh notice",
            "person not found", "no residence", "correct address", "enclosures due", "reg",
            "affidavit", "copies due", "ii batta", "sr stage", "caveator", "and others",
            "and another", "and", "others", "another", "lrs", "legal heirs", "deceased",
            "branch manager", "manager", "petitioner", "respondent", "appellant", "applicant",
            "opposite party", "defendant", "plaintiff", "complainant", "accused", "witness",
            "judge", "magistrate", "court", "bench"
    ));

    // Common prefixes to keep (these often indicate names)
    private static final Set<String> NAME_PREFIXES = new HashSet<>(Arrays.asList(
            "m/s", "m/s.", "s/o", "d/o", "w/o", "c/o", "dr", "dr.", "mr", "mr.", "mrs", "mrs.",
            "ms", "ms.", "adv", "advocate", "thirumathi", "thiru", "prof", "prof.", "the"
    ));

    // Pattern to match dates and file numbers
    private static final Pattern DATE_FILE_PATTERN = Pattern.compile(
            "\\b(?:usr|sr)\\.\\d+|\\d{1,2}\\.\\d{1,2}\\.\\d{4}|dt\\.\\d{2}\\.\\d{2}\\.\\d{4}|\\d+/\\d+/\\d{4}",
            Pattern.CASE_INSENSITIVE
    );

    // Pattern to match separators and noise
    private static final Pattern NOISE_PATTERN = Pattern.compile(
            "-{2,}|_{2,}|,{2,}|;|\\band\\b|\\bothers\\b|\\banother\\b|\\(.*?\\)|\\[.*?\\]",
            Pattern.CASE_INSENSITIVE
    );

    // Pattern to match Indian name formats
    private static final Pattern INDIAN_NAME_PATTERN = Pattern.compile(
            "\\b([A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*\\s*(?:S/O|D/O|W/O|C/O)?\\s*[A-Z][a-z]+(?:\\s+[A-Z][a-z]+)*)\\b",
            Pattern.CASE_INSENSITIVE
    );

    /**
     * Normalizes legal text and extracts valid names
     */
    public static List<String> extractAndNormalizeNames(String text) {
        if (text == null || text.trim().isEmpty()) {
            return Collections.emptyList();
        }

        // Step 1: Unicode normalization
        String normalizedText = Normalizer.normalize(text, Normalizer.Form.NFKC);

        // Step 2: Remove dates and file numbers
        String cleaned = DATE_FILE_PATTERN.matcher(normalizedText).replaceAll("");

        // Step 3: Remove common legal terms
        cleaned = removeLegalTerms(cleaned);

        // Step 4: Remove noise patterns
        cleaned = NOISE_PATTERN.matcher(cleaned).replaceAll(" ");

        // Step 5: Normalize whitespace and trim
        cleaned = cleaned.replaceAll("\\s+", " ").trim();

        // Step 6: Split by commas and process each part
        return Arrays.stream(cleaned.split(","))
                .map(String::trim)
                .filter(part -> !part.isEmpty())
                .map(CourtDataNormalizer::cleanNamePart)
                .filter(CourtDataNormalizer::isValidName)
                .distinct()
                .collect(Collectors.toList());
    }

    /**
     * Cleans individual name parts
     */
    private static String cleanNamePart(String namePart) {
        if (namePart == null || namePart.isEmpty()) {
            return "";
        }

        // Remove content in parentheses
        String cleaned = namePart.replaceAll("\\(.*?\\)", "");

        // Remove trailing special characters
        cleaned = cleaned.replaceAll("[.,;]+$", "");

        // Normalize case - title case for names
        cleaned = toTitleCase(cleaned);

        return cleaned.trim();
    }

    /**
     * Converts text to title case
     */
    private static String toTitleCase(String text) {
        if (text == null || text.isEmpty()) {
            return text;
        }

        // Check if text is all uppercase (common in legal docs)
        if (text.equals(text.toUpperCase())) {
            // Convert to title case
            String[] words = text.split("\\s+");
            StringBuilder result = new StringBuilder();

            for (String word : words) {
                if (word.length() > 1) {
                    result.append(Character.toUpperCase(word.charAt(0)))
                            .append(word.substring(1).toLowerCase())
                            .append(" ");
                } else {
                    result.append(word).append(" ");
                }
            }

            return result.toString().trim();
        }

        return text;
    }

    /**
     * Removes legal terms from text
     */
    private static String removeLegalTerms(String text) {
        String lowerText = text.toLowerCase();
        StringBuilder result = new StringBuilder(text);

        // Remove each legal term
        for (String term : LEGAL_TERMS) {
            Pattern termPattern = Pattern.compile("\\b" + Pattern.quote(term) + "\\b", Pattern.CASE_INSENSITIVE);
            Matcher matcher = termPattern.matcher(result.toString());
            result = new StringBuilder(matcher.replaceAll(""));
        }

        return result.toString();
    }

    /**
     * Validates if text is a valid name
     */
    private static boolean isValidName(String text) {
        if (text == null || text.length() < 2) return false;

        // Check if it contains digits
        if (text.matches(".*\\d.*")) return false;

        // Check if it's too long to be a name
        if (text.length() > 100) return false;

        // Check if it's a legal term
        String lowerText = text.toLowerCase();
        for (String term : LEGAL_TERMS) {
            if (lowerText.contains(term)) return false;
        }

        // Check if it has at least one alphabetic character
        if (!text.matches(".*[a-zA-Z].*")) return false;

        // Check for common name patterns
        if (text.matches("[A-Z]\\.([A-Z]\\.)?[A-Za-z]+")) return true;
        if (text.matches("[A-Z][a-z]+(\\s+[A-Z][a-z]+)*")) return true;

        return true;
    }

    /**
     * Specialized method for litigant names with different handling
     */
    public static List<String> extractAndNormalizeLitigantNames(String text) {
        List<String> names = extractAndNormalizeNames(text);

        // Additional litigant-specific processing
        return names.stream()
                .map(name -> {
                    // Handle "AND X OTHERS" pattern
                    if (name.toLowerCase().contains("and") &&
                            name.toLowerCase().contains("others")) {
                        return name.replaceAll("(?i)\\s+and\\s+\\d+\\s+others", "")
                                .replaceAll("(?i)\\s+&\\s+\\d+\\s+others", "");
                    }
                    return name;
                })
                .filter(name -> !name.isEmpty())
                .collect(Collectors.toList());
    }
}