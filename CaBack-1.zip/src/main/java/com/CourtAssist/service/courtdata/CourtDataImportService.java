package com.CourtAssist.service.courtdata;

import com.CourtAssist.model.CourtCase;
import com.CourtAssist.model.CourtHearing;
import com.CourtAssist.model.Litigant;
import com.CourtAssist.model.Advocate;
import com.CourtAssist.repository.CourtCaseRepository;
import com.CourtAssist.repository.CourtHearingRepository;
import com.CourtAssist.repository.LitigantRepository;
import com.CourtAssist.repository.AdvocateRepository;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class CourtDataImportService {

    private static final Logger logger = LoggerFactory.getLogger(CourtDataImportService.class);

    @Autowired
    private final RestTemplate restTemplate;

    private final CourtCaseRepository courtCaseRepository;
    private final CourtHearingRepository courtHearingRepository;
    private final LitigantRepository litigantRepository;
    private final AdvocateRepository advocateRepository;
    private final ObjectMapper objectMapper;

    private static final String MADURAI_HIGH_COURT_API = "https://mhc.tn.gov.in/judis/clists/clists-madurai/api/result.php";
    private static final String MADRAS_HIGH_COURT_API = "https://mhc.tn.gov.in/judis/clists/clists-madras/api/result.php";

    private static final Map<String, Integer> MONTH_MAP = createMonthMap();
    private static final DateTimeFormatter DATE_PARAM_FORMATTER = DateTimeFormatter.ofPattern("ddMMyyyy");
    private static final Pattern DATE_PATTERN = Pattern.compile(
            "ON\\s+\\w+\\s+THE\\s+(\\d+)(?:TH|ST|ND|RD)?\\s+DAY OF\\s+(\\w+)\\s+(\\d{4})\\s+AT\\s+(\\d{1,2})\\.(\\d{2})\\s+(A\\.M\\.|P\\.M\\.)",
            Pattern.CASE_INSENSITIVE
    );



    public CourtDataImportService(RestTemplate restTemplate, CourtCaseRepository courtCaseRepository,
                                  CourtHearingRepository courtHearingRepository, LitigantRepository litigantRepository,
                                  AdvocateRepository advocateRepository, ObjectMapper objectMapper) {
        this.restTemplate = restTemplate;
        this.courtCaseRepository = courtCaseRepository;
        this.courtHearingRepository = courtHearingRepository;
        this.litigantRepository = litigantRepository;
        this.advocateRepository = advocateRepository;
        this.objectMapper = objectMapper.copy();
        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Scheduled(cron = "${court-data.import.cron:0 0 6 * * ?}")
    public String importCourtData() {
        // Default behavior: import data for tomorrow
        return importCourtDataForDate(LocalDate.now().plusDays(1));
    }

    public String importCourtDataForDate(LocalDate date) {
        logger.info("Starting court data import process for date: {}", date);
        ImportResult result = new ImportResult();

        try {
            result.add(importHighCourtData(MADURAI_HIGH_COURT_API, "Madurai", date));
            result.add(importHighCourtData(MADRAS_HIGH_COURT_API, "Chennai", date));

            logger.info("Court data import completed successfully for {}: {}", date, result);
            return result.toString();
        } catch (Exception e) {
            logger.error("Error during court data import for {}: {}", date, e.getMessage());
            return "Failed to import court data for " + date + ": " + e.getMessage();
        }
    }

    private ImportResult importHighCourtData(String apiUrl, String district, LocalDate date)  {
        logger.info("Importing data from {} for district {} and date {}", apiUrl, district, date);
        ImportResult result = new ImportResult();

        try {
            String dateParam = date.format(DATE_PARAM_FORMATTER);
            String fullApiUrl = apiUrl + "?file=cause_" + dateParam + ".xml";

            logger.debug("Requesting URL: {}", fullApiUrl);
            String responseData = restTemplate.getForObject(fullApiUrl, String.class);

            if (responseData == null || responseData.trim().isEmpty()) {
                logger.warn("Empty response from API");
                return result;
            }

            List<CourtCaseApiResponse> apiResponses = parseApiResponse(responseData);
            logger.info("Found {} cases in response", apiResponses.size());

            processCourtCasesInBatch(apiResponses, district, result);


        } catch (Exception e) {
            logger.error("Failed to import data from {}: {}", apiUrl, e.getMessage());
            result.incrementFailed();
        }
        return result;
    }

    private void processCourtCasesInBatch(List<CourtCaseApiResponse> apiResponses, String district, ImportResult result) {
        int batchSize = 50;
        int totalCases = apiResponses.size();

        logger.info("Processing {} cases in batches of {}", totalCases, batchSize);

        for (int i = 0; i < totalCases; i += batchSize) {
            int endIndex = Math.min(i + batchSize, totalCases);
            List<CourtCaseApiResponse> batch = apiResponses.subList(i, endIndex);

            logger.debug("Processing batch from {} to {}", i, endIndex - 1);

            for (CourtCaseApiResponse apiResponse : batch) {
                try {
                    processCourtCase(apiResponse, district);
                    result.incrementSuccess();
                } catch (Exception e) {
                    logger.error("Failed to process court case: {}", e.getMessage());
                    result.incrementFailed();
                }
            }

            // Instead of using EntityManager.flush(), use repository saveAll methods
            // This will be handled by Spring's transaction management
            if (i % 200 == 0) {
                logger.debug("Processed {} cases", i);
            }
        }

        logger.debug("Completed processing all {} cases", totalCases);
    }

    private List<CourtCaseApiResponse> parseApiResponse(String responseData) {
        try {
            JsonNode rootNode = objectMapper.readTree(responseData);

            if (rootNode.isArray()) {
                List<CourtCaseApiResponse> responses = new ArrayList<>();
                for (JsonNode node : rootNode) {
                    responses.add(parseCourtCase(node));
                }
                return responses;
            } else if (rootNode.isObject()) {
                return Collections.singletonList(parseCourtCase(rootNode));
            } else {
                logger.error("Unexpected API response format");
                return Collections.emptyList();
            }
        } catch (Exception e) {
            logger.error("Failed to parse API response: {}", e.getMessage());
            return Collections.emptyList();
        }
    }

    private CourtCaseApiResponse parseCourtCase(JsonNode node) {
        CourtCaseApiResponse response = new CourtCaseApiResponse();

        // Parse basic fields
        response.setCourtno(getText(node, "courtno"));
        response.setCourtremarks(getText(node, "courtremarks"));
        response.setStagename(getText(node, "stagename"));
        response.setMcasetype(getText(node, "mcasetype"));
        response.setMcaseno(getText(node, "mcaseno"));
        response.setMcaseyr(getText(node, "mcaseyr"));
        response.setPname(getText(node, "pname"));
        response.setRname(getText(node, "rname"));
        response.setMpadv(getTextOrFirstFromArray(node, "mpadv"));
        response.setMradv(getTextOrFirstFromArray(node, "mradv"));

        // Parse extra cases with simplified approach
        JsonNode extraNode = node.get("extra");
        if (extraNode != null && extraNode.isObject()) {
            ExtraCasesApiResponse extra = new ExtraCasesApiResponse();
            extra.setExcaseno(getListFromNode(extraNode, "excaseno"));
            extra.setExcaseyr(getListFromNode(extraNode, "excaseyr"));
            extra.setExcasetype(getListFromNode(extraNode, "excasetype"));
            extra.setExpname(getListFromNode(extraNode, "expname"));
            extra.setExrname(getListFromNode(extraNode, "exrname"));
            extra.setExpadv(getListFromNode(extraNode, "expadv"));
            extra.setExradv(getListFromNode(extraNode, "exradv"));
            response.setExtra(extra);
        }

        return response;
    }

    private String getText(JsonNode node, String fieldName) {
        JsonNode fieldNode = node.get(fieldName);
        return (fieldNode != null && fieldNode.isTextual()) ? fieldNode.asText() : "";
    }

    private Object getTextOrFirstFromArray(JsonNode node, String fieldName) {
        JsonNode fieldNode = node.get(fieldName);
        if (fieldNode == null) return "";
        if (fieldNode.isTextual()) return fieldNode.asText();
        if (fieldNode.isArray() && fieldNode.size() > 0) return fieldNode.get(0).asText();
        return "";
    }

    private List<String> getListFromNode(JsonNode node, String fieldName) {
        JsonNode fieldNode = node.get(fieldName);
        List<String> result = new ArrayList<>();

        if (fieldNode != null) {
            if (fieldNode.isTextual()) {
                result.add(fieldNode.asText());
            } else if (fieldNode.isArray()) {
                for (JsonNode item : fieldNode) {
                    if (item.isTextual()) {
                        result.add(item.asText());
                    }
                }
            }
        }

        return result;
    }

    private void processCourtCase(CourtCaseApiResponse apiResponse, String district) {
        try {
            // Process main case
            CourtCase mainCase = createOrUpdateMainCase(apiResponse, district);

            // Process hearing for main case
            createOrUpdateHearing(apiResponse, mainCase);

            // Process litigant for main case (enhanced)
            createOrUpdateLitigant(apiResponse, mainCase);

            // Process advocates for main case (enhanced)
            createOrUpdateAdvocates(apiResponse, mainCase);

            // Process extra cases if they exist
            if (apiResponse.getExtra() != null && !apiResponse.getExtra().isEmpty()) {
                processExtraCases(apiResponse.getExtra(), mainCase, district);
            }

        } catch (Exception e) {
            logger.error("Failed to process court case: {}", e.getMessage());
            throw e;
        }
    }


    private CourtCase createOrUpdateMainCase(CourtCaseApiResponse apiResponse, String district) {
        String caseId = generateCaseId(apiResponse.getMcaseno(), apiResponse.getMcaseyr());

        CourtCase courtCase = courtCaseRepository.findById(caseId).orElse(new CourtCase());

        if (courtCase.getCaseId() == null) {
            courtCase.setCaseId(caseId);
        }

        // Set case properties from API response
        courtCase.setState("Tamil Nadu");
        courtCase.setDistrict(district);
        courtCase.setCourtComplex(district + " High Court");
        courtCase.setCourtLevel(CourtCase.CourtLevel.HIGH_COURT);
        courtCase.setCaseType(apiResponse.getMcasetype());
        courtCase.setCaseNo(apiResponse.getMcaseno());
        courtCase.setCaseYear(Integer.parseInt(apiResponse.getMcaseyr()));

        return courtCaseRepository.save(courtCase);
    }

    private void createOrUpdateHearing(CourtCaseApiResponse apiResponse, CourtCase courtCase) {
        CourtHearing hearing = new CourtHearing();
        hearing.setHearingId(generateHearingId());
        hearing.setCourtCase(courtCase);
        hearing.setCourtNo(apiResponse.getCourtno());
        hearing.setStage(apiResponse.getStagename());
        hearing.setHearingDatetime(parseHearingDateTime(apiResponse.getCourtremarks()));
        hearing.setCourtRemarks(apiResponse.getCourtremarks());

        courtHearingRepository.save(hearing);
    }

    private void createOrUpdateLitigant(CourtCaseApiResponse apiResponse, CourtCase courtCase) {
        // Extract and normalize petitioner names
        List<String> petitionerNames = CourtDataNormalizer.extractAndNormalizeLitigantNames(apiResponse.getPname());

        // Extract and normalize respondent names
        List<String> respondentNames = CourtDataNormalizer.extractAndNormalizeLitigantNames(apiResponse.getRname());

        // Process petitioner names
        for (String petitionerName : petitionerNames) {
            if (!petitionerName.isEmpty()) {
                // Check if litigant already exists
                Optional<Litigant> existingLitigant = litigantRepository.findByCaseIdAndPetitioner(
                        courtCase.getCaseId(), petitionerName
                );

                Litigant litigant;
                if (existingLitigant.isPresent()) {
                    litigant = existingLitigant.get();
                    // Update existing litigant if needed
                } else {
                    litigant = new Litigant();
                    litigant.setCase_(courtCase);
                    litigant.setPetitioner(petitionerName);
                    litigant.setRespondent(""); // Will be set separately for respondents
                }
                litigantRepository.save(litigant);
            }
        }

        // Process respondent names
        for (String respondentName : respondentNames) {
            if (!respondentName.isEmpty()) {
                // Check if litigant already exists
                Optional<Litigant> existingLitigant = litigantRepository.findByCaseIdAndRespondent(
                        courtCase.getCaseId(), respondentName
                );

                Litigant litigant;
                if (existingLitigant.isPresent()) {
                    litigant = existingLitigant.get();
                    // Update existing litigant if needed
                } else {
                    litigant = new Litigant();
                    litigant.setCase_(courtCase);
                    litigant.setPetitioner(""); // Empty for respondent
                    litigant.setRespondent(respondentName);
                }
                litigantRepository.save(litigant);
            }
        }

        // Handle case where we have a single litigant with both petitioner and respondent
        if (petitionerNames.size() == 1 && respondentNames.size() == 1) {
            Optional<Litigant> existingLitigant = litigantRepository.findByCaseIdAndPetitioner(
                    courtCase.getCaseId(), petitionerNames.get(0)
            );

            if (existingLitigant.isPresent()) {
                Litigant litigant = existingLitigant.get();
                // If this litigant only has petitioner set, add respondent
                if (litigant.getRespondent() == null || litigant.getRespondent().isEmpty()) {
                    litigant.setRespondent(respondentNames.get(0));
                    litigantRepository.save(litigant);
                }
            }
        }
    }

    private void createOrUpdateAdvocates(CourtCaseApiResponse apiResponse, CourtCase courtCase) {
        // Process petitioner advocates
        if (apiResponse.getMpadv() != null) {
            List<String> petitionerAdvocates = CourtDataNormalizer.extractAndNormalizeNames(
                    apiResponse.getMpadv().toString()
            );

            for (String advocateName : petitionerAdvocates) {
                // Check if advocate already exists
                Optional<Advocate> existingAdvocate = advocateRepository.findByCaseIdAndPetitionerAdv(
                        courtCase.getCaseId(), advocateName
                );

                if (existingAdvocate.isPresent()) {
                    // Update existing advocate if needed
                    Advocate advocate = existingAdvocate.get();
                    // Add any update logic here if needed
                    advocateRepository.save(advocate);
                } else {
                    // Create new advocate
                    Advocate petitionerAdvocate = new Advocate();
                    petitionerAdvocate.setCase_(courtCase);
                    petitionerAdvocate.setPetitionerAdv(advocateName);
                    petitionerAdvocate.setRespondentAdv("");
                    advocateRepository.save(petitionerAdvocate);
                }
            }
        }

        // Process respondent advocates
        if (apiResponse.getMradv() != null) {
            List<String> respondentAdvocates = CourtDataNormalizer.extractAndNormalizeNames(
                    apiResponse.getMradv().toString()
            );

            for (String advocateName : respondentAdvocates) {
                // Check if advocate already exists
                Optional<Advocate> existingAdvocate = advocateRepository.findByCaseIdAndRespondentAdv(
                        courtCase.getCaseId(), advocateName
                );

                if (existingAdvocate.isPresent()) {
                    // Update existing advocate if needed
                    Advocate advocate = existingAdvocate.get();
                    // Add any update logic here if needed
                    advocateRepository.save(advocate);
                } else {
                    // Create new advocate
                    Advocate respondentAdvocate = new Advocate();
                    respondentAdvocate.setCase_(courtCase);
                    respondentAdvocate.setPetitionerAdv("");
                    respondentAdvocate.setRespondentAdv(advocateName);
                    advocateRepository.save(respondentAdvocate);
                }
            }
        }
    }

    private void processExtraCases(ExtraCasesApiResponse extraCases, CourtCase mainCase, String district) {
        if (extraCases == null || extraCases.isEmpty()) {
            return;
        }

        List<String> excasenoList = extraCases.getExcaseno();
        if (excasenoList == null || excasenoList.isEmpty()) {
            return;
        }

        for (int i = 0; i < excasenoList.size(); i++) {
            try {
                String caseNo = excasenoList.get(i);
                String caseYear = extraCases.getExcaseyr().size() > i ?
                        extraCases.getExcaseyr().get(i) : "";

                if (caseNo == null || caseNo.isEmpty() || caseYear == null || caseYear.isEmpty()) {
                    continue;
                }

                String caseId = generateCaseId(caseNo, caseYear);

                // Check if extra case already exists
                CourtCase extraCase = courtCaseRepository.findById(caseId).orElse(new CourtCase());

                if (extraCase.getCaseId() == null) {
                    extraCase.setCaseId(caseId);
                }

                // Set extra case properties
                extraCase.setState("Tamil Nadu");
                extraCase.setDistrict(district);
                extraCase.setCourtComplex(district + " High Court");
                extraCase.setCourtLevel(CourtCase.CourtLevel.HIGH_COURT);
                extraCase.setCaseType(
                        extraCases.getExcasetype().size() > i ?
                                extraCases.getExcasetype().get(i) : ""
                );
                extraCase.setCaseNo(caseNo);
                extraCase.setCaseYear(Integer.parseInt(caseYear));
                extraCase.setParentCase(mainCase);

                CourtCase savedCase = courtCaseRepository.save(extraCase);

                // Process litigants for extra case with normalized names
                if (extraCases.getExpname() != null && i < extraCases.getExpname().size() &&
                        extraCases.getExrname() != null && i < extraCases.getExrname().size()) {

                    List<String> petitionerNames = CourtDataNormalizer.extractAndNormalizeLitigantNames(
                            extraCases.getExpname().get(i) != null ?
                                    extraCases.getExpname().get(i) : ""
                    );

                    List<String> respondentNames = CourtDataNormalizer.extractAndNormalizeLitigantNames(
                            extraCases.getExrname().get(i) != null ?
                                    extraCases.getExrname().get(i) : ""
                    );

                    // Process petitioner names
                    for (String petitionerName : petitionerNames) {
                        if (!petitionerName.isEmpty()) {
                            Optional<Litigant> existingLitigant = litigantRepository.findByCaseIdAndPetitioner(
                                    savedCase.getCaseId(), petitionerName
                            );

                            if (existingLitigant.isPresent()) {
                                // Update existing if needed
                                Litigant litigant = existingLitigant.get();
                                litigantRepository.save(litigant);
                            } else {
                                Litigant litigant = new Litigant();
                                litigant.setCase_(savedCase);
                                litigant.setPetitioner(petitionerName);
                                litigant.setRespondent("");
                                litigantRepository.save(litigant);
                            }
                        }
                    }

                    // Process respondent names
                    for (String respondentName : respondentNames) {
                        if (!respondentName.isEmpty()) {
                            Optional<Litigant> existingLitigant = litigantRepository.findByCaseIdAndRespondent(
                                    savedCase.getCaseId(), respondentName
                            );

                            if (existingLitigant.isPresent()) {
                                // Update existing if needed
                                Litigant litigant = existingLitigant.get();
                                litigantRepository.save(litigant);
                            } else {
                                Litigant litigant = new Litigant();
                                litigant.setCase_(savedCase);
                                litigant.setPetitioner("");
                                litigant.setRespondent(respondentName);
                                litigantRepository.save(litigant);
                            }
                        }
                    }
                }

                // Process advocates for extra case (same as before)
                // ... [existing advocate processing code] ...

            } catch (Exception e) {
                logger.error("Failed to process extra case at index {}: {}", i, e.getMessage());
            }
        }
    }

    private String generateCaseId(String caseNo, String caseYear) {
        return "TamilNadu/" + caseNo + "/" + caseYear;
    }

    private String generateHearingId() {
        return "HEAR-" + System.currentTimeMillis() + "-" + (int) (Math.random() * 1000);
    }

    private LocalDateTime parseHearingDateTime(String courtRemarks) {
        try {
            // First try to parse with time
            Matcher matcher = DATE_PATTERN.matcher(courtRemarks);
            if (matcher.find()) {
                String day = matcher.group(1);
                String monthName = matcher.group(2);
                String year = matcher.group(3);
                String hour = matcher.group(4);
                String minute = matcher.group(5);
                String period = matcher.group(6);

                int month = convertMonthNameToNumber(monthName);
                int hourInt = parseHour(hour, period);

                return LocalDateTime.of(
                        Integer.parseInt(year),
                        month,
                        Integer.parseInt(day),
                        hourInt,
                        Integer.parseInt(minute)
                );
            }

            // If time not found, try to parse just the date
            Pattern dateOnlyPattern = Pattern.compile(
                    "ON\\s+\\w+\\s+THE\\s+(\\d+)(?:TH|ST|ND|RD)?\\s+DAY OF\\s+(\\w+)\\s+(\\d{4})",
                    Pattern.CASE_INSENSITIVE
            );

            Matcher dateMatcher = dateOnlyPattern.matcher(courtRemarks);
            if (dateMatcher.find()) {
                String day = dateMatcher.group(1);
                String monthName = dateMatcher.group(2);
                String year = dateMatcher.group(3);

                int month = convertMonthNameToNumber(monthName);

                // Return with default time (start of day)
                return LocalDateTime.of(
                        Integer.parseInt(year),
                        month,
                        Integer.parseInt(day),
                        0, 0 // Default to 00:00 hours
                );
            }
        } catch (Exception e) {
            logger.warn("Failed to parse hearing date from remarks: {}", courtRemarks);
        }

        // Return tomorrow's date as fallback
        return LocalDateTime.now().plusDays(1).withHour(0).withMinute(0);
    }

    private int convertMonthNameToNumber(String monthName) {
        return MONTH_MAP.getOrDefault(monthName.toUpperCase(), 1);
    }

    private int parseHour(String hour, String period) {
        int hourInt = Integer.parseInt(hour);
        if ("P.M.".equals(period) && hourInt < 12) {
            hourInt += 12;
        } else if ("A.M.".equals(period) && hourInt == 12) {
            hourInt = 0;
        }
        return hourInt;
    }

    private static Map<String, Integer> createMonthMap() {
        Map<String, Integer> map = new HashMap<>();
        map.put("JANUARY", 1);
        map.put("FEBRUARY", 2);
        map.put("MARCH", 3);
        map.put("APRIL", 4);
        map.put("MAY", 5);
        map.put("JUNE", 6);
        map.put("JULY", 7);
        map.put("AUGUST", 8);
        map.put("SEPTEMBER", 9);
        map.put("OCTOBER", 10);
        map.put("NOVEMBER", 11);
        map.put("DECEMBER", 12);
        return map;
    }

    // Simplified inner classes for API response parsing
    @Setter
    @Getter
    public static class CourtCaseApiResponse {
        // Getters and setters
        private String courtno;
        private String courtremarks;
        private String stagename;
        private String mcasetype;
        private String mcaseno;
        private String mcaseyr;
        private String pname;
        private String rname;
        private Object mpadv;
        private Object mradv;
        private ExtraCasesApiResponse extra;

    }

    @Setter
    @Getter
    public static class ExtraCasesApiResponse {
        // Getters and setters
        private List<String> excasetype = new ArrayList<>();
        private List<String> excaseno = new ArrayList<>();
        private List<String> excaseyr = new ArrayList<>();
        private List<String> expname = new ArrayList<>();
        private List<String> exrname = new ArrayList<>();
        private List<String> expadv = new ArrayList<>();
        private List<String> exradv = new ArrayList<>();

        public boolean isEmpty() {
            return (excaseno == null || excaseno.isEmpty()) &&
                    (excaseyr == null || excaseyr.isEmpty());
        }
    }

    // Inner class to track import results
    private static class ImportResult {
        private int successfulImports = 0;
        private int failedImports = 0;

        public void incrementSuccess() {
            successfulImports++;
        }

        public void incrementFailed() {
            failedImports++;
        }

        public void add(ImportResult other) {
            this.successfulImports += other.successfulImports;
            this.failedImports += other.failedImports;
        }

        @Override
        public String toString() {
            return String.format("Successful imports: %d, Failed imports: %d",
                    successfulImports, failedImports);
        }
    }
}