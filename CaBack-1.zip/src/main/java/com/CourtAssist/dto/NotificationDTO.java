package com.CourtAssist.dto;

import com.CourtAssist.model.CourtCase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class NotificationDTO {
    private Long id;
    private String caseNo;
    private Integer caseYear;
    private LocalDateTime hearingDatetime;
    private CourtCase.CourtLevel courtLevel;
    private String state;
    private String district;
    private String courtComplex;
    private String courtNo;
    private String stage;
    private String petitioner;
    private String respondent;
    private String petitionerAdv;
    private String respondentAdv;
    private LocalDateTime createdAt;
    private Boolean isRead;

    public String getCourtLevel(){
        return courtLevel.toString();
    }
}
