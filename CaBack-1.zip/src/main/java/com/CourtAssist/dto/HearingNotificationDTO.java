package com.CourtAssist.dto;


import lombok.Getter;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Getter
public class HearingNotificationDTO {
    private String caseNumber;
    private LocalDateTime hearingDateTime;
    private String courtName;
    private String stage;
    private String hearingId;
    private String petitionerName;
    private String respondentName;
    private String petitionerAdvocate;
    private String respondentAdvocate;
    private final String formattedMessage;

    public HearingNotificationDTO(String caseNumber, LocalDateTime hearingDateTime, String courtName,
                                  String stage, String hearingId, String petitionerName,
                                  String respondentName, String petitionerAdvocate, String respondentAdvocate) {
        this.caseNumber = caseNumber;
        this.hearingDateTime = hearingDateTime;
        this.courtName = courtName;
        this.stage = stage;
        this.hearingId = hearingId;
        this.petitionerName = petitionerName;
        this.respondentName = respondentName;
        this.petitionerAdvocate = petitionerAdvocate;
        this.respondentAdvocate = respondentAdvocate;
        this.formattedMessage = generateFormattedMessage();
    }

    public HearingNotificationDTO(String formattedMessage) {
        this.formattedMessage = formattedMessage;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public void setHearingDateTime(LocalDateTime hearingDateTime) {
        this.hearingDateTime = hearingDateTime;
    }

    public void setCourtName(String courtName) {
        this.courtName = courtName;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public void setHearingId(String hearingId) {
        this.hearingId = hearingId;
    }

    public void setPetitionerName(String petitionerName) {
        this.petitionerName = petitionerName;
    }

    public void setRespondentName(String respondentName) {
        this.respondentName = respondentName;
    }

    public void setPetitionerAdvocate(String petitionerAdvocate) {
        this.petitionerAdvocate = petitionerAdvocate;
    }

    public void setRespondentAdvocate(String respondentAdvocate) {
        this.respondentAdvocate = respondentAdvocate;
    }

    private String generateFormattedMessage() {
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("h:mm a");

        return String.format(
                "Hearing Notice: %s\nDate: %s\nTime: %s\nCourt: %s\nStage: %s\nPetitioner: %s\nRespondent: %s\nPetitioner Advocate: %s\nRespondent Advocate: %s",
                caseNumber,
                hearingDateTime.format(dateFormatter),
                hearingDateTime.format(timeFormatter),
                courtName,
                stage,
                petitionerName,
                respondentName,
                petitionerAdvocate,
                respondentAdvocate
        );
    }
}